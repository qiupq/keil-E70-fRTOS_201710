Revised Version: V00020.20;        Revised Date: 2013.03.20
 

Revised By: Brandon.Chang

The Drivers are made for products employed Ralink RT2070, RT3070, RT3072,RT5370, RT5372 chipsets. 

The RT2870 is the kernel software of the RT3x7x and RT5x7x Chipset. Ralink didn't identify the driver difference between RT2870 and RT3x7x, as well as RT5x7x. 

=========================================================================================================
Softwares contents and version:

1. Windows: RalinkWLAN Driver,MT7601chipset for MT7601 only. 

   It supports Windows XP/Vista/7/8, RT3x7X supports Windows 2000 also.

2. Linux: 2011_0719_RT3070_RT3370_RT5370_RT5372_Linux_STA_V2.5.0.3_DPO

4. Macintosh: RTUSB D2870-4.2.4.0 UI-4.0.7.0_2012_06_14.dmg
             
   It supports: Mac OS X 10.6/10.7/10.8

5. Add supports of Linux and Windows XP/Vista/7/8 for MT7601 chipset

----------------------------------------------------------------------------------------------------------
=========================================================================================================
Softwares contents and version(MTK Driver V2.0):
1.windows driver version: 
	IS_AP_STA_RT2870_D-5.1.9.0_VA-5.1.9.0_W7-5.1.9.0_W8-5.1.9.0_RU-5.0.8.0_AU-5.0.3.15_121013_1.5.31.3WP_Free.exe\
2.linux driver version:
	DPA_MT7601U_LinuxSTA_3.0.0.4_20130916.tar.bz2
	DPA_RT5572_LinuxSTA_2.6.1.4_20121211.tar.bz2
	MT7601U_LinuxAP_3.0.0.1_20130802.tar.bz2
	RT5572_RT5372_Linux_AP_V2.7.1.1_Beta_DPA_20121113.tar.bz2
3.mac driver version:
	RTUSB D2870-4.2.6.0 UI-4.0.8.0_2012_09_28.dmg
4.android driver version:
	DPA_MT7601U_LinuxAP_ANDROID_20121211.tar.bz2
	DPA_MT7601U_LinuxSTA_ANDROID_JB_20121121.tar.bz2
	PortableAP.rar
	STA_DPA_BETA_RT5X_JB_V2.6.1.0_20121123.tar.gz

The drivers support RT3x7x and RT5x7x Chipset and MT7601 Chipset .

----------------------------------------------------------------------------------------------------------
The drivers can be downloaded from Ralink website, the present offical website to download the latest version driver is:

http://www.ralinktech.com/en/04_support/support.php?sn=500.








